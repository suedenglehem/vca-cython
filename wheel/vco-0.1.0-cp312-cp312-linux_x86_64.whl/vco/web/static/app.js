"use strict";
const $ = (id) => document.getElementById(id);
const fmtSize = (n) => n > 1048576 ? (n / 1048576).toFixed(1) + " MB"
  : n > 1024 ? (n / 1024).toFixed(0) + " KB" : n + " B";

// --- tabs ---------------------------------------------------------------------
function showTab(name) {
  for (const s of ["analyze", "jobs", "config", "about"]) {
    $("tab-" + s).classList.toggle("hidden", s !== name);
  }
  for (const b of document.querySelectorAll(".tab")) {
    b.classList.toggle("active", b.dataset.tab === name);
  }
  try { localStorage.setItem("vca-tab", name); } catch (e) { /* private mode */ }
}
for (const b of document.querySelectorAll(".tab")) {
  b.addEventListener("click", () => showTab(b.dataset.tab));
}
try {
  const saved = localStorage.getItem("vca-tab");
  if (saved) showTab(saved);
} catch (e) { /* private mode */ }

// --- files: clickable list (scales to 1000s), with filter ---------------------
let FILES = [];
let selectedFile = null;

function renderFiles() {
  const q = $("filefilter").value.toLowerCase();
  const list = $("filelist");
  list.innerHTML = "";
  const shown = FILES.filter((f) => !q || f.name.toLowerCase().includes(q));
  if (!shown.length) {
    list.innerHTML = '<li class="muted">no files' + (q ? " match the filter" : "") + "</li>";
    return;
  }
  for (const f of shown) {
    const li = document.createElement("li");
    if (f.name === selectedFile) li.classList.add("sel");
    const name = document.createElement("span");
    name.textContent = f.name;
    const size = document.createElement("span");
    size.className = "size";
    size.textContent = fmtSize(f.size_bytes);
    li.append(name, size);
    li.addEventListener("click", () => {
      selectedFile = f.name;
      $("file").value = f.name;
      $("selectedfile").textContent = f.name;
      renderFiles();
    });
    list.append(li);
  }
}

async function loadFiles() {
  const r = await fetch("/api/files");
  const d = await r.json();
  FILES = d.files;
  if (selectedFile && !FILES.some((f) => f.name === selectedFile)) {
    selectedFile = null; $("file").value = ""; $("selectedfile").textContent = "(none)";
  }
  renderFiles();
}
$("filefilter").addEventListener("input", renderFiles);
// Refresh: refetch the file list — the server also drops reports of vanished
// files there when the purge option is on.
$("refresh").addEventListener("click", loadFiles);

// --- jobs: detail div (status/progress/evidence/artifacts) -------------------
// The LIST is an iframe (/jobs, static/jobs.js, latest 30); this page renders
// only the detail panel below it, driven by selectJob() — which jobs.js in the
// iframe calls as window.parent.selectJob(). The report iframe (#jobframe)
// carries ONLY the report.
const EVIDENCE = ["continuity.json", "probe.json", "rejection.txt"];
let currentJob = null;
let detailTimer = null;

function setStatus(j) {
  const el = $("statusline");
  el.textContent = j.status;
  el.className = "status s-" + j.status;
  $("errline").textContent = j.error_code
    ? j.error_code + ": " + j.error_message : "";
  $("cancelbtn").classList.toggle("hidden",
    j.status !== "queued" && j.status !== "running");
}

function renderEvents(events) {
  $("events").textContent = events
    .map((e) => "[" + String(e.t).padStart(6, " ") + "s] " + e.stage
      + (e.code ? " " + e.code : ""))
    .join("\n");
}

async function showArtifacts(id) {
  const r = await fetch(`/api/jobs/${id}/artifacts`);
  if (!r.ok) return;
  const d = await r.json();
  const arts = d.artifacts.filter((n) => !EVIDENCE.includes(n));
  const evid = d.artifacts.filter((n) => EVIDENCE.includes(n));
  const ul = $("artifactlist");
  ul.innerHTML = "";
  for (const n of arts) {
    const li = document.createElement("li");
    li.innerHTML = `<a href="/api/jobs/${id}/files/${n}">${n}</a>`;
    ul.append(li);
  }
  $("artifacts").classList.toggle("hidden", arts.length === 0);
  const hasReport = d.artifacts.includes("report.html");
  const frame = $("jobframe");
  frame.classList.toggle("hidden", !hasReport);
  frame.src = hasReport ? `/api/jobs/${id}/report` : "about:blank";
  const el = $("evidencelist");
  el.innerHTML = "";
  for (const n of evid) {
    const li = document.createElement("li");
    li.innerHTML = `<a href="/api/jobs/${id}/files/${n}">${n}</a>`;
    el.append(li);
  }
  $("evidence").classList.toggle("hidden", d.status !== "rejected" && evid.length === 0);
  $("rejection").textContent = "";
  if (d.artifacts.includes("rejection.txt")) {
    const t = await fetch(`/api/jobs/${id}/files/rejection.txt`);
    $("rejection").textContent = await t.text();
  }
}

async function pollJob(id) {
  const r = await fetch(`/api/jobs/${id}`);
  if (!r.ok || currentJob !== id) return;
  const j = await r.json();
  setStatus(j);
  renderEvents(j.events);
  if (j.status === "queued" || j.status === "running") {
    detailTimer = setTimeout(() => pollJob(id), 1000);
  } else {
    showArtifacts(id);
  }
}

function selectJob(id) {
  if (detailTimer) clearTimeout(detailTimer);
  currentJob = id;
  $("jobdetail").classList.remove("hidden");
  $("evidence").classList.add("hidden");
  $("artifacts").classList.add("hidden");
  $("rejection").textContent = "";
  pollJob(id);
}

$("cancelbtn").addEventListener("click", async () => {
  if (currentJob) await fetch(`/api/jobs/${currentJob}/cancel`, { method: "POST" });
});

async function loadJobs() {
  // The table itself renders inside the #jobslist iframe; here we only
  // auto-select the newest job for the detail panel below it.
  if (currentJob) return;
  const r = await fetch("/api/jobs?limit=1");
  if (!r.ok) return;
  const d = await r.json();
  if (d.jobs.length) selectJob(d.jobs[0].id);
}

// --- theme: colors only — an html[data-theme] palette over the base "gray" ------
// Iframes are separate documents: the jobs list uses style.css's palettes,
// the report carries its own injected token block. Re-apply the attribute to
// each same-origin iframe so the live preview reaches them too.
function setThemeAttr(root, t) {
  if (t && t !== "gray") root.dataset.theme = t;
  else delete root.dataset.theme;
}
function applyTheme(t) {
  setThemeAttr(document.documentElement, t);
  for (const id of ["jobslist", "jobframe"]) {
    try {
      const w = $(id) && $(id).contentWindow;
      const doc = w && w.document;
      if (doc && doc.documentElement) setThemeAttr(doc.documentElement, t);
      // The report re-lays-out its plotly chart from the CSS vars it just got
      // (pre-theme reports have no themeChart — rerunning the job makes one).
      if (id === "jobframe" && typeof w.themeChart === "function") w.themeChart();
    } catch (e) { /* not loaded yet */ }
  }
}

// --- config: host folder mapping (input + output) -------------------------------
// Live color preview before Apply; the pick persists only on Apply.
$("cfg-theme").addEventListener("change", () => applyTheme($("cfg-theme").value));

async function loadConfig() {
  const r = await fetch("/api/config");
  if (!r.ok) return;
  const d = await r.json();
  $("cfg-path").value = d.host_dir || d.input_dir;
  $("cfg-out-path").value = d.host_output_dir || d.output_dir;
  $("cfg-theme").value = d.theme || "dark";
  $("cfg-purge").checked = !!d.purge;
  $("cfg-no-continuity").checked = !!d.no_continuity;
  // Info only: the GPU is pinned at container start (CUDA_VISIBLE_DEVICES),
  // the web can report it, not change it.
  $("cfg-gpu-used").textContent = d.gpu_used
    ? "GPU used: " + d.gpu_used
    : "no NVIDIA GPU visible to this container (GPU operations unavailable)";
  const ver = [d.ffmpeg_version, d.tsp_version].filter(Boolean).join("\n\n");
  const el = $("about-versions");
  el.textContent = ver;
  el.classList.toggle("hidden", !ver);
}

$("cfgform").addEventListener("submit", async (e) => {
  e.preventDefault();
  const r = await fetch("/api/config", {
    method: "POST", headers: { "content-type": "application/json" },
    body: JSON.stringify({ input_dir: $("cfg-path").value,
                           output_dir: $("cfg-out-path").value,
                           theme: $("cfg-theme").value,
                           purge: $("cfg-purge").checked,
                           no_continuity: $("cfg-no-continuity").checked }),
  });
  const d = await r.json().catch(() => ({}));
  $("cfg-status").textContent = r.ok
    ? "applied: in " + (d.host_dir || d.input_dir) + " → out " + (d.host_output_dir || d.output_dir)
      + " · " + d.theme + (d.purge ? " · purge on" : "")
    : "failed: " + (d.detail || r.status);
  if (r.ok) { selectedFile = null; $("file").value = "";
             $("selectedfile").textContent = "(none)"; loadFiles(); loadConfig();
             // Authoritative state back to the DOM; the iframes re-theme live.
             applyTheme(d.theme); }
});

// --- new job ------------------------------------------------------------------
$("jobform").addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!selectedFile) { alert("pick a file in the list first"); return; }
  const btn = e.target.querySelector("button");
  btn.disabled = true;
  const body = {
    file: selectedFile, mode: $("mode").value, rank_by: $("rank_by").value,
    frames: $("frames").checked,
    ts_continuity: $("ts_continuity").value || null,
  };
  const r = await fetch("/api/jobs", {
    method: "POST", headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  btn.disabled = false;
  if (r.ok) {
    const d = await r.json();
    showTab("jobs");
    selectJob(d.id);  // the iframe's own 2 s poll picks the new row up
  } else {
    const d = await r.json().catch(() => ({}));
    alert("submit failed: " + (d.detail || r.status));
  }
});

// --- batch: All / All* (queue many files at once) ------------------------------
// All  = every file without a report yet; All* = every file.
// The fired button turns into "Stop" until the whole batch is terminal;
// Stop cancels the queued jobs and flags the in-flight one (it finishes,
// then is marked cancelled — same semantics as a single-job cancel).
let BATCH = null;         // {id, kind} of the active batch
let batchTimer = null;    // 2 s poll handle
let modalOk = null;       // pending confirmation callback

function batchFormBody() {
  return { mode: $("mode").value, rank_by: $("rank_by").value,
           frames: $("frames").checked,
           ts_continuity: $("ts_continuity").value || null };
}

// fired = the kind that started the batch (its button shows "Stop");
// the other button is disabled while the batch is active. running=false →
// both back to All / All*.
function setBatchUi(fired, running) {
  for (const [id, k] of [["batch-all", "All"], ["batch-allstar", "All*"]]) {
    const btn = $(id);
    const kind = k === "All" ? "all" : "allstar";
    btn.classList.remove("stop");
    if (!running) { btn.textContent = k; btn.disabled = false; continue; }
    if (kind === fired) { btn.textContent = "Stop"; btn.classList.add("stop"); }
    else { btn.textContent = k; btn.disabled = true; }
  }
}

function setBatchLine(text) {
  const el = $("batchline");
  el.textContent = text;
  el.classList.toggle("hidden", !text);
}

function stopBatchUi() {
  BATCH = null;
  if (batchTimer) { clearTimeout(batchTimer); batchTimer = null; }
  setBatchUi(null, false);
}

async function pollBatch(id) {
  const r = await fetch(`/api/batches/${id}`);
  if (!r.ok || BATCH === null || BATCH.id !== id) { stopBatchUi(); return; }
  const b = await r.json();
  if (b.done < b.total) {
    const parts = [`Batch ${b.done}/${b.total}`];
    if (b.failed) parts.push(b.failed + " failed");
    if (b.current) parts.push("· " + b.current);
    else if (b.stopped) parts.push("· stopping");
    setBatchLine(parts.join(" — "));
    batchTimer = setTimeout(() => pollBatch(id), 2000);
  } else {
    stopBatchUi();
    setBatchLine(`Batch done: ${b.done}/${b.total}`
      + (b.failed ? ` (${b.failed} failed)` : ""));
    loadFiles();  // refresh has_report for the next All click
  }
}

async function stopBatch() {
  if (!BATCH) return;
  const id = BATCH.id;
  if (batchTimer) { clearTimeout(batchTimer); batchTimer = null; }
  await fetch(`/api/batches/${id}/stop`, { method: "POST" });
  setBatchLine("Batch stopped — the in-flight file finishes, the rest are cancelled");
  pollBatch(id);  // keep polling for the final state
}

async function startBatch(kind) {
  const files = kind === "all" ? FILES.filter((f) => !f.has_report) : FILES.slice();
  if (!files.length) {
    setBatchLine(kind === "all"
      ? "all files already have reports (use All*)"
      : "no files in the input folder");
    return;
  }
  const n = files.length;
  showModal(`Analyze ${n} file${n === 1 ? "" : "s"} one by one${
    kind === "all"
      ? ` — skipping ${FILES.length - n} with a report already`
      : ", including those with a report already"}?\n\nMode: ${$("mode").value} · rank by ${$("rank_by").value}`
    + ($("frames").checked ? " · per-frame CSV" : "")
    + ($("ts_continuity").value ? " · TS " + $("ts_continuity").value : ""),
    async () => {
      const body = Object.assign({ skip_existing: kind === "all" }, batchFormBody());
      const r = await fetch("/api/batches", {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!r.ok) {
        const d = await r.json().catch(() => ({}));
        setBatchLine("batch failed: " + (d.detail || r.status));
        return;
      }
      const b = await r.json();
      BATCH = { id: b.id, kind };
      setBatchUi(kind, true);
      setBatchLine(`Batch started: ${b.total} file${b.total === 1 ? "" : "s"} queued`);
      showTab("jobs");
      pollBatch(b.id);
    });
}

function onBatchClick(kind) {
  if (BATCH && BATCH.kind === kind) stopBatch();
  else startBatch(kind);
}
$("batch-all").addEventListener("click", () => onBatchClick("all"));
$("batch-allstar").addEventListener("click", () => onBatchClick("allstar"));

// Restore an in-flight batch after a page reload (server kept the queue).
async function restoreBatch() {
  const r = await fetch("/api/batches");
  if (!r.ok) return;
  const b = (await r.json()).batches[0];
  if (!b) return;
  BATCH = { id: b.id, kind: b.kind };
  setBatchUi(b.kind, true);
  setBatchLine(`Batch in progress: ${b.done}/${b.total}`
    + (b.stopped ? " (stopping)" : ""));
  pollBatch(b.id);
}

// --- confirm modal (textContent only — file names are untrusted) ---------------
function showModal(msg, onOk) {
  $("modal-msg").textContent = msg;
  modalOk = onOk;
  $("modal").classList.remove("hidden");
}
function hideModal() {
  $("modal").classList.add("hidden");
  modalOk = null;
}
$("modal-ok").addEventListener("click", () => { const f = modalOk; hideModal(); if (f) f(); });
$("modal-cancel").addEventListener("click", hideModal);
$("modal").addEventListener("click", (e) => { if (e.target === $("modal")) hideModal(); });
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && !$("modal").classList.contains("hidden")) hideModal();
});

loadFiles();
loadJobs();
loadConfig();
restoreBatch();
