"use strict";
const $ = (id) => document.getElementById(id);
const EVIDENCE = ["continuity.json", "probe.json", "rejection.txt"];

function setStatus(j) {
  const el = $("statusline");
  el.textContent = j.status;
  el.className = "status s-" + j.status;
  $("errline").textContent = j.error_code
    ? j.error_code + ": " + j.error_message : "";
  $("cancelbtn").classList.toggle("hidden",
    j.status !== "queued" && j.status !== "running");
}

function renderEvents(events) {
  $("events").textContent = events
    .map((e) => "[" + String(e.t).padStart(6, " ") + "s] " + e.stage
      + (e.code ? " " + e.code : ""))
    .join("\n");
}

async function showArtifacts() {
  const r = await fetch(`/api/jobs/${JOB_ID}/artifacts`);
  if (!r.ok) return;
  const d = await r.json();
  const arts = d.artifacts.filter((n) => !EVIDENCE.includes(n));
  const evid = d.artifacts.filter((n) => EVIDENCE.includes(n));
  const isRejected = d.status === "rejected";
  const ul = $("artifactlist");
  ul.innerHTML = "";
  for (const n of arts) {
    const li = document.createElement("li");
    li.innerHTML = `<a href="/api/jobs/${JOB_ID}/files/${n}">${n}</a>`;
    ul.append(li);
  }
  $("artifacts").classList.toggle("hidden", arts.length === 0);
  $("reportsec").classList.toggle("hidden", !d.artifacts.includes("report.html"));
  if (d.artifacts.includes("report.html")) $("reportframe").src = `/api/jobs/${JOB_ID}/report`;
  const el = $("evidencelist");
  el.innerHTML = "";
  for (const n of evid) {
    const li = document.createElement("li");
    li.innerHTML = `<a href="/api/jobs/${JOB_ID}/files/${n}">${n}</a>`;
    el.append(li);
  }
  $("evidence").classList.toggle("hidden", !isRejected && evid.length === 0);
  if (d.artifacts.includes("rejection.txt")) {
    const t = await fetch(`/api/jobs/${JOB_ID}/files/rejection.txt`);
    $("rejection").textContent = await t.text();
  }
}

$("cancelbtn").addEventListener("click", async () => {
  await fetch(`/api/jobs/${JOB_ID}/cancel`, { method: "POST" });
});

async function poll() {
  const r = await fetch(`/api/jobs/${JOB_ID}`);
  if (!r.ok) return;
  const j = await r.json();
  setStatus(j);
  renderEvents(j.events);
  if (j.status === "queued" || j.status === "running") {
    setTimeout(poll, 1000);
  } else {
    showArtifacts();
  }
}
poll();
