"use strict";
// Jobs list (static/jobs.js) — the table embedded in the main UI's iframe
// (/jobs), but works standalone too. Shows only the latest 30 jobs (the full
// history can reach thousands); `total` in the caption carries the real count.
// Row click: selects the job in the parent UI's detail panel (same-origin
// iframe) or navigates to the standalone job page when loaded directly.
const LIMIT = 30;
const EMBEDDED = window.parent !== window;

function $(id) { return document.getElementById(id); }

function elapsed(j) {
  return j.finished_s && j.started_s
    ? (j.finished_s - j.started_s).toFixed(1) + " s"
    : j.started_s ? "…" : "";
}

function select(id) {
  if (EMBEDDED) window.parent.selectJob(id);
  else window.location.href = "/jobs/" + id;
}

function render(d) {
  $("total").textContent = d.total;
  $("shown").textContent = d.jobs.length;
  const tb = $("jobtable").tBodies[0];
  tb.innerHTML = "";
  for (const j of d.jobs) {
    const tr = document.createElement("tr");
    const idTd = document.createElement("td");
    const idLink = document.createElement("a");
    idLink.href = "/jobs/" + j.id;
    idLink.textContent = j.id;
    idLink.addEventListener("click", (e) => { e.preventDefault(); select(j.id); });
    idTd.append(idLink);
    const fileTd = document.createElement("td");
    fileTd.textContent = j.filename;
    const modeTd = document.createElement("td");
    modeTd.textContent = j.mode;
    const stTd = document.createElement("td");
    stTd.className = "s-" + j.status;
    stTd.textContent = j.status;
    const elTd = document.createElement("td");
    elTd.textContent = elapsed(j);
    const actTd = document.createElement("td");
    if (j.status === "completed") {
      const a = document.createElement("a");
      a.href = "/api/jobs/" + j.id + "/report";
      a.target = "_blank";
      a.textContent = "report";
      a.addEventListener("click", (e) => e.stopPropagation());
      actTd.append(a);
    }
    tr.append(idTd, fileTd, modeTd, stTd, elTd, actTd);
    tr.addEventListener("click", () => select(j.id));
    tb.append(tr);
  }
}

async function load() {
  const r = await fetch("/api/jobs?limit=" + LIMIT);
  if (!r.ok) return;
  render(await r.json());
}
load();
setInterval(load, 2000);
